package com.example.mycamera

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.Camera
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat


class MainActivity : AppCompatActivity() {
    private lateinit var galleryOpenId: AppCompatButton
    private lateinit var cameraOpenId: AppCompatButton
    private lateinit var viewImage: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        checkCameraHardware(this)
        init()

    }
    private fun init(){
        galleryOpenId = findViewById(R.id.button) as AppCompatButton
        cameraOpenId = findViewById(R.id.buttonCamera) as AppCompatButton
        viewImage = findViewById(R.id.img) as ImageView

        galleryOpenId.setOnClickListener({
            chooseImageGallery()

//            Toast.makeText(this,"",Toast.LENGTH_SHORT).show()
        })
        cameraOpenId.setOnClickListener(
            {
                val camera_intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                startActivityForResult(camera_intent, 123)
            }

        )
    }
    companion object {
        private val IMAGE_CHOOSE = 1000;
        private val PERMISSION_CODE = 1001;
    }
    private val REQUEST_CODE = 13
    private val currentCameraId: Int = Camera.CameraInfo.CAMERA_FACING_BACK


    // This method will help to retrieve the image
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // Match the request 'pic id with requestCode
        if (requestCode == 123) {
            // BitMap is data structure of image file which store the image in memory
            val photo = data!!.extras!!["data"] as Bitmap?
            // Set the image in imageview for display
            viewImage.setImageBitmap(photo)
        }else {

            viewImage.setImageURI(data?.data)
        }
    }
    private fun takePick(){
        Camera.open(currentCameraId)
    }
    private fun chooseImageGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, IMAGE_CHOOSE)
    }
    private fun checkCameraHardware(context: Context): Boolean {
        if (context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
            // this device has a camera
            Log.i("checkPermission", "Result : this device has a camera")
            checkDeviceVersion()
            return true
        } else {
            // no camera on this device
            Log.i("checkPermission", "Result : no camera on this device")
            return false
        }
    }

    private fun checkDeviceVersion() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            // only for gingerbread and newer versions
            Log.i("checkPermission", "Device Version Result : your device version is  33")
            onClickRequestPermission()
        } else {
            Log.i("checkPermission", "Device Version Result : less then device version is  33")
        }
    }

    fun onClickRequestPermission() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED -> {
                /*layout.showSnackbar(
                    view,
                    getString(R.string.permission_granted),
                    Snackbar.LENGTH_INDEFINITE,
                    null
                ) {}*/
            }

            ActivityCompat.shouldShowRequestPermissionRationale(
                this,
                Manifest.permission.CAMERA
            ) -> {
                requestPermissionLauncher.launch(
                    Manifest.permission.CAMERA
                )
                /*layout.showSnackbar(
                    view,
                    getString(R.string.permission_required),
                    Snackbar.LENGTH_INDEFINITE,
                    getString(R.string.ok)
                ) {
                    requestPermissionLauncher.launch(
                        Manifest.permission.CAMERA
                    )
                }*/
            }

            else -> {
                requestPermissionLauncher.launch(
                    Manifest.permission.CAMERA
                )
            }
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                Log.i("checkPermission: ", "Granted")
            } else {
                Log.i("checkPermission: ", "Denied")
            }
        }
}